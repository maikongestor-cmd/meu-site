<?php
/**
 * Funções auxiliares: ícones, links de contato.
 *
 * @package MengoMantos
 */

defined( 'ABSPATH' ) || exit;

/**
 * Retorna um ícone SVG inline.
 *
 * @param string $name Nome do ícone.
 * @return string
 */
function pm_icon( $name ) {
	$icons = array(
		'search'   => '<path d="M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm10 2-4.35-4.35" />',
		'user'     => '<path d="M20 21a8 8 0 0 0-16 0" /><circle cx="12" cy="7" r="4" />',
		'bag'      => '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" /><path d="M3 6h18M16 10a4 4 0 0 1-8 0" />',
		'menu'     => '<path d="M3 6h18M3 12h18M3 18h18" />',
		'close'    => '<path d="M18 6 6 18M6 6l12 12" />',
		'arrow'    => '<path d="M5 12h14m-6-6 6 6-6 6" />',
		'pix'      => '<path d="m12 2.5 4.2 4.2-4.2 4.2-4.2-4.2zM12 13.1l4.2 4.2-4.2 4.2-4.2-4.2zM2.5 12l4.2-4.2 4.2 4.2-4.2 4.2zM13.1 12l4.2-4.2 4.2 4.2-4.2 4.2z" />',
		'truck'    => '<path d="M1 3h15v13H1zM16 8h4l3 3v5h-7z" /><circle cx="5.5" cy="18.5" r="2.5" /><circle cx="18.5" cy="18.5" r="2.5" />',
		'refresh'  => '<path d="M21 2v6h-6M3 22v-6h6" /><path d="M20.5 15A9 9 0 0 1 5.6 18.4L3 16M3.5 9A9 9 0 0 1 18.4 5.6L21 8" />',
		'card'     => '<rect x="1" y="4" width="22" height="16" rx="2" /><path d="M1 10h22" />',
		'shield'   => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-4" />',
		'ruler'    => '<path d="M21.3 8.7 8.7 21.3a1 1 0 0 1-1.4 0l-4.6-4.6a1 1 0 0 1 0-1.4L15.3 2.7a1 1 0 0 1 1.4 0l4.6 4.6a1 1 0 0 1 0 1.4ZM7.5 10.5l2 2M10.5 7.5l2 2M13.5 4.5l2 2M4.5 13.5l2 2" />',
		'mail'     => '<rect x="2" y="4" width="20" height="16" rx="2" /><path d="m22 6-10 7L2 6" />',
		'phone'    => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z" />',
		'pin'      => '<path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0Z" /><circle cx="12" cy="10" r="3" />',
		'check'    => '<path d="M20 6 9 17l-5-5" />',
	);

	if ( 'whatsapp' === $name ) {
		return '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M17.5 14.4c-.3-.1-1.8-.9-2-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.2-.2.2-.3.2-.6.1-.3-.1-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.4-.5c.2-.2.2-.3.3-.5.1-.2 0-.4 0-.5l-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.2 5.1 4.5.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.8-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.2-.3-.3-.6-.4ZM12 21.8c-1.8 0-3.5-.5-5-1.4l-.4-.2-3.7 1 1-3.6-.2-.4A9.8 9.8 0 1 1 12 21.8Zm8.4-18.2A11.8 11.8 0 0 0 1.7 17.8L0 24l6.3-1.7A11.8 11.8 0 0 0 24 12a11.7 11.7 0 0 0-3.6-8.4Z"/></svg>';
	}
	if ( 'instagram' === $name ) {
		return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true" focusable="false"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>';
	}
	if ( 'facebook' === $name ) {
		return '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M14 8h3V4h-3a4 4 0 0 0-4 4v2H8v4h2v8h4v-8h3l1-4h-4V8Z"/></svg>';
	}
	if ( 'tiktok' === $name ) {
		return '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M16.6 5.8A4.3 4.3 0 0 1 15.5 3h-3.1v12.4a2.6 2.6 0 1 1-2.6-2.6c.3 0 .5 0 .8.1V9.7a5.7 5.7 0 1 0 4.9 5.7V9a7.4 7.4 0 0 0 4.3 1.4V7.3a4.3 4.3 0 0 1-3.2-1.5Z"/></svg>';
	}
	if ( ! isset( $icons[ $name ] ) ) {
		return '';
	}
	return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $icons[ $name ] . '</svg>';
}

/**
 * Imprime um ícone (SVG fixo do tema, seguro).
 *
 * @param string $name Nome.
 */
function pm_the_icon( $name ) {
	echo pm_icon( $name ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Lê uma opção do Personalizador com valor padrão.
 *
 * @param string $key Chave sem prefixo.
 * @return mixed
 */
function pm_opt( $key ) {
	$defaults = pm_defaults();
	return get_theme_mod( 'pm_' . $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
}

/**
 * Corrige o CNPJ antigo caso tenha sido salvo no Personalizar.
 */
function pm_fix_old_cnpj() {
	if ( '30.105.559/0001-47' === get_theme_mod( 'pm_cnpj' ) ) {
		set_theme_mod( 'pm_cnpj', '30.105.559/0001-76' );
	}
}
add_action( 'after_setup_theme', 'pm_fix_old_cnpj', 20 );

/**
 * Troca os textos antigos dos banners (se tiverem sido salvos no Personalizar) pelos novos padrões.
 */
function pm_fix_old_slide_texts() {
	$old = array(
		'pm_slide2_text' => 'Blusão com capuz + calça jogger em moletom flanelado. Tamanhos do P ao GG.',
		'pm_slide3_text' => 'Logo P + escudo histórico, em algodão. E calças moletom por R$ 147.',
	);
	foreach ( $old as $key => $text ) {
		if ( get_theme_mod( $key ) === $text ) {
			remove_theme_mod( $key );
		}
	}
}
add_action( 'after_setup_theme', 'pm_fix_old_slide_texts', 20 );

/**
 * Valores padrão (rascunho — editar em Aparência → Personalizar → Mengo Mantos).
 *
 * @return array
 */
function pm_defaults() {
	return array(
		'topbar'         => '5% de desconto no Pix · Frete grátis acima de R$ 249 · Troca gratuita',
		'whatsapp'       => '5511918214971',
		'whatsapp_msg'   => 'Olá! Vim pelo site da Mengo Mantos e gostaria de mais informações.',
		'phone'          => '(11) 91821-4971',
		'email'          => 'contato@mengomantos.com.br',
		'instagram'      => 'https://www.instagram.com/mengomantos/',
		'facebook'       => 'https://facebook.com/mengomantos',
		'tiktok'         => '',
		'address'        => 'Rio de Janeiro — RJ',
		'cnpj'           => '39.252.739/0001-69',
		'company'        => 'Mengo Mantos',
		'pix_discount'   => 5,
		'free_shipping'  => 249,
		'installments'   => 12,
		'hero_eyebrow'   => 'Coleção Mengo',
		'hero_title'     => 'Paixão e <em>Estilo!</em>',
		'hero_text'      => 'Moletons, calças e camisetas para vestir o manto no dia a dia — com conforto, qualidade e a nossa história no peito.',
		'hero_image_1'   => '',
		'hero_image_2'   => '',
		// Avaliações no Instagram.
		'ig_reviews_count' => 0,
		'ig_reviews_url'   => '',
		// Apresentação da marca.
		'welcome_title'  => 'Bem-vindo ao Mengo Mantos',
		'welcome_text'   => "Mengo Mantos nasceu da paixão de um torcedor que sempre acreditou que vestir uma camisa vai muito além da roupa. É carregar a raça, a história e o orgulho de quem vive o vermelho e preto todos os dias.\n\nCriamos esta marca para pessoas como você: torcedores que procuram qualidade, conforto e peças exclusivas para representar seu amor pelo clube dentro e fora dos estádios.",
		'welcome_sign'   => 'De rubro-negro para rubro-negro ❤️🖤',
		'news_title'     => 'Receba as novidades da Mengo Mantos',
		'news_text'      => 'Lançamentos, promoções e cupons exclusivos direto no seu e-mail.',
		// Banner rotativo (3 slides).
		'slide1_image'   => '',
		'slide1_eyebrow' => 'Coleção Mengo',
		'slide1_title'   => 'Paixão e <em>Estilo!</em>',
		'slide1_text'    => 'Moletons, calças e camisetas para vestir o manto no dia a dia — com conforto, qualidade e a nossa história no peito.',
		'slide1_points'  => '',
		'slide1_button'  => 'Ver coleção',
		'slide1_link'    => '',
		'slide2_image'   => '',
		'slide2_eyebrow' => 'Black Friday Mengo',
		'slide2_title'   => 'Conjunto moletom <em>R$ 267</em>',
		'slide2_text'    => 'Moletom flanelado e forrado, com estampa que não solta e nem desbota.',
		'slide2_points'  => "Estampa que não desbota\nFlanelado e forrado\nConforto que dura",
		'slide2_button'  => 'Comprar conjunto',
		'slide2_link'    => '',
		'slide3_image'   => '',
		'slide3_eyebrow' => 'Black Friday Mengo',
		'slide3_title'   => 'Camiseta oversized <em>R$ 137</em>',
		'slide3_text'    => 'Camisetas oversized 100% algodão, com o CRF no peito e a arte 81·19·22·25 nas costas.',
		'slide3_points'  => "100% algodão\nEstampa que não desbota\nConforto que dura",
		'slide3_button'  => 'Comprar camiseta',
		'slide3_link'    => '',
		'split_title'    => 'Vista o manto no dia a dia',
		'split_text'     => 'Peças em moletom flanelado e algodão de alta gramatura, estampas que não desbotam e modelagem pensada para o conforto — da arquibancada ao rolê.',
	);
}

/**
 * Link do WhatsApp.
 *
 * @param string $message Mensagem opcional.
 * @return string
 */
function pm_whatsapp_url( $message = '' ) {
	$number = preg_replace( '/\D+/', '', (string) pm_opt( 'whatsapp' ) );
	if ( '' === $message ) {
		$message = pm_opt( 'whatsapp_msg' );
	}
	return 'https://wa.me/' . $number . '?text=' . rawurlencode( $message );
}

/**
 * URL de uma imagem do tema.
 *
 * @param string $file Arquivo em assets/img.
 * @return string
 */
function pm_img( $file ) {
	return PM_URI . '/assets/img/' . $file;
}

/**
 * Imagem do Personalizador ou padrão do tema.
 *
 * @param string $key      Opção.
 * @param string $fallback Arquivo padrão.
 * @return string
 */
function pm_opt_img( $key, $fallback ) {
	$url = pm_opt( $key );
	return $url ? $url : pm_img( $fallback );
}

/**
 * Formata dinheiro em reais (fora do WooCommerce também).
 *
 * @param float $value Valor.
 * @return string
 */
function pm_money( $value ) {
	return 'R$ ' . number_format( (float) $value, 2, ',', '.' );
}

/**
 * Link de uma categoria de produto ou da loja.
 *
 * @param string $slug Slug.
 * @return string
 */
function pm_cat_url( $slug ) {
	if ( taxonomy_exists( 'product_cat' ) ) {
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			return get_term_link( $term );
		}
	}
	return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
}

/**
 * Logo do cabeçalho/rodapé.
 */
function pm_logo() {
	if ( has_custom_logo() ) {
		the_custom_logo();
		return;
	}
	printf(
		'<a class="pm-logo" href="%1$s" rel="home"><img src="%2$s" alt="" width="46" height="60"><span class="pm-logo__text">Mengo<small>Mantos</small></span><span class="screen-reader-text">%3$s</span></a>',
		esc_url( home_url( '/' ) ),
		esc_url( pm_img( 'logo-mark.png' ) ),
		esc_html( get_bloginfo( 'name' ) )
	);
}

/**
 * Aviso no site (só para administradores) quando a loja ainda não está pronta.
 */
function pm_admin_store_warning() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$msg  = '';
	$link = admin_url( 'themes.php?page=pm-setup' );
	if ( ! class_exists( 'WooCommerce' ) ) {
		$msg  = __( 'O plugin WooCommerce não está ativo, então ainda não existem produtos, categorias nem carrinho. Ative em Plugins e depois rode a configuração da loja.', 'palestra-mantos' );
		$link = admin_url( 'plugins.php' );
	} else {
		$count = wp_count_posts( 'product' );
		if ( empty( $count->publish ) ) {
			$msg = __( 'O WooCommerce está ativo, mas ainda não há produtos publicados. Clique aqui e depois em "Criar conteúdo da loja".', 'palestra-mantos' );
		}
	}
	if ( $msg ) {
		printf(
			'<div class="pm-admin-warning"><a href="%s">⚠️ %s</a> <small>%s</small></div>',
			esc_url( $link ),
			esc_html( $msg ),
			esc_html__( '(aviso visível só para administradores)', 'palestra-mantos' )
		);
	}
}
add_action( 'wp_body_open', 'pm_admin_store_warning', 5 );


/**
 * Link e total das avaliações no Instagram.
 *
 * @return array array( total, url )
 */
function pm_ig_reviews() {
	$count = (int) pm_opt( 'ig_reviews_count' );
	$url   = pm_opt( 'ig_reviews_url' ) ? pm_opt( 'ig_reviews_url' ) : pm_opt( 'instagram' );
	return array( $count, $url );
}

/**
 * Botão "Quer ver mais? Veja as +200 avaliações no Instagram".
 *
 * @return string
 */
function pm_ig_reviews_cta() {
	list( $count, $url ) = pm_ig_reviews();
	if ( $count <= 0 || ! $url ) {
		return '';
	}
	return sprintf(
		'<div class="pm-ig-cta"><p>%s</p><a class="pm-btn pm-btn--outline" href="%s" target="_blank" rel="noopener">%s %s</a></div>',
		esc_html__( 'Quer ver mais?', 'palestra-mantos' ),
		esc_url( $url ),
		pm_icon( 'instagram' ),
		/* translators: %d: total. */
		esc_html( sprintf( __( 'Veja as +%d avaliações no nosso Instagram', 'palestra-mantos' ), $count ) )
	);
}
